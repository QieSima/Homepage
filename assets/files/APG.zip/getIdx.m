function idx = getIdx(T,n)
    idx = 1:n;
    idx = idx(T > 0);
    s = randperm(length(idx));
    idx = idx(s);
end