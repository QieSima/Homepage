function k = Kernel(x,y)
    %choose rbf
    %gamma = 0.001;
    %k = exp(-gamma*(norm(x-y,2)^2));
    %k = x'*y;
    k = x*y';
end