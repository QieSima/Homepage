function [b,acc] = getB(a,X,Y)
    
    n = length(Y);
    
% ======== Linear Kernel ========
%     KM = X*X';
%     Ya = Y.*a;
%     y_pred = KM*Ya;

% ========= Poly Kernel =========
%     g = 0.5; r = 1.0; d = 0.5;
%     KM = (g*(X*X')+r).^d;
%     Ya = Y.*a;
%     y_pred = KM*Ya;
    
% ========= RBF Kernel ==========
    g = 0.001;
    W = X*X';
    E = exp(-g*W);
    L = diag(E);
    KM = (L*L').*(E.^(-2));
    Ya = Y.*a;
    y_pred = KM*Ya;

% =============== GET B ================
    %plot y_pred
    idx1 = [];
    idx2 = [];
    for i = 1:n
        if (Y(i) == -1)
            idx1 = [idx1 i];
        else
            idx2 = [idx2 i];
        end
    end
    y1 = sort(y_pred(idx1));
    y2 = sort(y_pred(idx2));
    
    %get b
    i1 = length(y1);
    i2 = 1;
    while (y1(i1) > y2(i2))
        i1 = i1 - 1;
        i2 = i2 + 1;
    end
    b = -(y1(i1)+y2(i2))/2;
    
    %get training accuracy
    ys = sign(y_pred + b*ones(n,1));
    acc = sum(ys == Y)/length(Y);
end