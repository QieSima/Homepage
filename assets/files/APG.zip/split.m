function [setB,nB,start,T,Tmax] = split(g,a,idx,tol,U,q,start,T,Tmax,Y)

  n = length(idx);
  setB = zeros(q,1);
  nB = 0;
  for pos = start:n
      if (nB == q) break, end
      i = idx(pos);
      gi = g(i);
      ai = a(i);
      if ((((ai <= tol)&&(ai >= 0)) && (gi <= -tol)) || (((ai > tol)&&(ai < U-tol)) && (abs(gi) > tol)) || (((ai >= U-tol)&&(ai <= U)) && (gi >= tol)))
          nB = nB + 1;
          setB(nB) = i;
          T(i) = max(0,T(i)-1);
          %Tmax = max(Tmax,T(i));
      else
          T(i) = min(Tmax,T(i)+1);
      end
  end
  start = pos;
  setB = setB(1:nB);
  if (nB ~= 0)
    count = sum(Y(setB) < 0);
    if count == 0
      W = (Y < 0) & (a > 0) & (a < U);
      s = 1:length(Y);
      s = s(W);
      L = min(length(s),max(10,floor(q/10)));
      setB = [setB;s(1:L)'];
      nB = nB + L;
    else
      if count == nB
          W = (Y > 0) & (a > 0) & (a < U);
          s = 1:length(Y);
          s = s(W);
          L = min(length(s),max(10,floor(q/10)));
          setB = [setB;s(1:L)'];
          nB = nB + L;
      end
    end
  end
end