function [Qii,w,U] = getQWU(type,C)
    if (type == 0)
        Qii = 0;
        w = 1;
        U = C;
    else
        w = 0;
        if (type == 1)
            Qii = 0;
            U = C;
        else
            if (type == 2)
                Qii = 1/(2*C);
                U = inf;
            end
        end
    end
end