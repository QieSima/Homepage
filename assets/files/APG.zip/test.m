function ret = test()
    
% ======================= read image training data ========================
%     X = sparse((loadMNISTImages("train-images-idx3-ubyte"))');
%     Y = loadMNISTLabels("train-labels-idx1-ubyte"); 
%     [X,Y] = get2classes(X,Y,1,2);
%     X = X(1:1000,:);
%     Y = Y(1:1000);
%     size(X)
%     disp(['Training Sample Size: ',num2str(length(Y))]);
    
% ======================= read rcv1 training data ========================
    Y = textread("dataset/rcv1/y.txt","%d");
    Y = Y(1:5000);
    X = sparse(length(Y),47236);
    for i = 1:length(Y)
        f = ['dataset/rcv1/ncdata/',num2str(i),'.txt'];
        [I,J,V] = textread(f,"%d%d%f");
        X(i,I) = V;
        if mod(i,100) == 0
            disp(i);
        end
    end

    % my model training process
    [alpha, tPSBCM] = train(X,Y,length(Y),1e-6,2,1.0,500,10,3); 
    disp(['PSBCM Time:',num2str(tPSBCM),'s']);          
    [b,train_acc] = getB(alpha,X,Y);
    disp(['PSBCM Training Accuracy:',num2str(train_acc)]);
    
    %libsvm training process
    tic, cmd = ' -t 2 -c 1.0 -g 1.0'; model = svmtrain(Y,X,cmd); tLIBSVM = toc;
    disp(['LibSVM Time:',num2str(tLIBSVM),'s']);
    svmpredict(Y,X,model);
    
% ======================= read image testing data ========================
%     X_test = sparse((loadMNISTImages("t10k-images-idx3-ubyte"))');
%     Y_test = loadMNISTLabels("t10k-labels-idx1-ubyte");
%     [X_test,Y_test] = get2classes(X_test,Y_test,1,2);
%     X_test = X_test(1:1000,:);
%     Y_test = Y_test(1:1000);
%     disp(['Testing Sample Size: ',num2str(length(Y_test))]);

    
% ======================= read rcv1 testing data ========================
    Y_test = textread("dataset/rcv1/ytest.txt","%d");
    Y_test = Y_test(1:1000);
    X_test = sparse(length(Y_test),47236);
    for i = 1:length(Y_test)
        f = ['dataset/rcv1/nctest/',num2str(i),'.txt'];
        [I,J,V] = textread(f,"%d%d%f");
        X_test(i,I) = V;
    end

    % test accuracy
    Y_pred2 = predict(alpha,b,X,Y,X_test,length(Y_test));
    test_acc = sum(Y_pred2 == Y_test)/length(Y_test);
    disp(['PSBCM Testing Accuracy:',num2str(test_acc)]);
    svmpredict(Y_test,X_test,model);
    
    ret = 1;
end