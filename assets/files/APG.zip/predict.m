function y_pred = predict(a,b,X,Y,Xtest,nt)

% ================= Linear Kernel =================
%     Ya = Y.*a;                  % n*1
%     KM = Xtest*X';              % nt*n
%     y_pred = sign(KM*Ya + b);   % nt*1

% =============== Polynominal Kernel ===============
%     g = 0.5; r = 1.0; d = 0.5;
%     Ya = Y.*a;
%     KM = (g*(Xtest*X')+r).^d;
%     y_pred = sign(KM*Ya + b);

% ================ RBF Kernel ====================    
    g = 0.001;
    W = Xtest*X';                   %nt * n
    E = exp(-g*W);                  %nt * n
    n = length(Y);
    xx = zeros(n,1);
    for i = 1:n xx(i) = X(i,:)*(X(i,:)'); end
    xx = exp(-g*xx);
    xtxt = zeros(nt,1);
    for i = 1:nt xtxt(i) = Xtest(i,:)*(Xtest(i,:)'); end
    xtxt = exp(-g*xtxt);
    KM = (xtxt * xx').*(E.^(-2));   % nt * n
    Ya = Y.*a;                      % n * 1
    y_pred = sign(KM*Ya+b);         % nt * 1
    
end