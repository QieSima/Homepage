function [Alpha,t_total] = train(X,Y,n,tol,type,C,q,beta,Ci)

    [Qii,w,U] = getQWU(type,C);
    
    if (w ~= 0)
        disp("Haven't implemented for C-SVM.");
        Alpha = zeros(length(Y),1);
        t_total = -999999;
        return;
    end
    
    disp("Start Making Q Matrix ...");
    tic, Qp = makeQ(X,Y,n,Qii); tQ = toc;                     
    
    a = randn(n,1);
    r = -ones(n,1);
    cnt = 0;
    
    terminate_iter = n/q;                                  
    disp(['Terminate bound: ',num2str(terminate_iter)]);

    idx = randperm(n);
    g = Qp*a + r;
    start = 1;
    T = ones(n,1);
    Tmax = 3;
    
    ep = tol;
    options = optimoptions(@quadprog,'Display','off','OptimalityTolerance',ep);
    
    tic
    cir = 0;
    iter = 0;
    while (1==1)
        
        [setB,nB,start,T,Tmax] = split(g,a,idx,tol,U,q,start,T,Tmax,Y);
        if (nB/n < tol)
            if (cir == Ci)
                T(T == 0) = 1;
                %Tmax = max(Tmax,1);
                cir = -1;
            end
            idx = getIdx(T,n);
            start = 1;
            cir = cir + 1;
            [setB,nB,start,T,Tmax] = split(g,a,idx,tol,U,q,start,T,Tmax,Y);
            if (nB/n < tol) break; end
        end
        %setB = setB(1:nB);
        
        QBB = Qp(setB,setB);                                
        dta = max(5e-5,max(max(eig(QBB)),4*q*beta)*1e-8);                                             
        asetB = a(setB);
        f = g(setB) - QBB*asetB;                            
        
        if (mod(cnt,50) == 0) ep = ep/10; options = optimoptions(@quadprog,'Display','off','OptimalityTolerance',ep); end
        aB_best = quadprog(QBB + dta*sparse(eye(nB)), f - dta*asetB,[],[],[],[],zeros(nB,1),U*ones(nB,1),asetB,options);
        %aB_best = quadprog(QBB, f,[],[],[],[],zeros(nB,1),U*ones(nB,1),asetB,options);
        dert_B = aB_best - asetB;
        %dert_a = sum(abs(dert_B))/sum(abs(asetB));
        disp([num2str(cnt+1),'  ',num2str(nB)]);%,'  ',num2str(dert_a)]);
        
        a(setB) = aB_best;
        cnt = cnt + 1;
        
        %if (dert_a < tol) iter = iter + 1; end
        %if (iter >= terminate_iter) break; end
        
        g = g + Qp(:,setB)*dert_B;
    end
    t_iter = toc;
    
    disp(['Making Q:',num2str(tQ)]);
    t_total = t_iter + tQ;
    Alpha = a;
    
    %tic, quadprog(Qp,r,[],[],[],[], zeros(n,1), U*ones(n,1),randn(n,1),options); t_naive = toc;
    %disp(['Once QP:',num2str(t_naive)]);
    %disp(['PSBCM:',num2str(t_total)]);
end