function [X,Y] = get2classes(X,Y,l1,l2)
    n = length(Y);
    idx = [];
    l1_cnt = 0;
    l2_cnt = 0;
    for i = 1:n
        if (Y(i) == l1) %(mod(Y(i),2) == 1) %(Y(i) == l1) 
            Y(i) = -1;
            idx = [idx i];
            l1_cnt = l1_cnt + 1;
            continue
        end
        if (Y(i) == l2) %(mod(Y(i),2) == 0) %(Y(i) == l2) 
            Y(i) = 1;
            idx = [idx i];
            l2_cnt = l2_cnt + 1;
            continue
        end
    end
    disp(['class num: ',num2str(l1_cnt),' ',num2str(l2_cnt)]);
    X = X(idx,:);
    Y = Y(idx);
end