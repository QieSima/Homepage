function Qp = makeQ(X,Y,n,Qii)
    
% ======= Linear Kernel ========= 
%   Qp = (Y*Y').*(X*X');

% ======= Poly Kernel ===========
%     g = 0.5; r = 1.0; d = 0.5;
%     Qp = (Y*Y').*((g*(X*X')+r).^d);
    
% ======= RBF Kernel ============
    g = 0.001;
    W = X*X';
    E = full(exp(-g*W));
    L = diag(E).*Y;
    Qp = (L*L').*(E.^(-2));

    if (Qii ~= 0)
        for i = 1:n
            Qp(i,i) = Qp(i,i) + Qii;
        end
    end
end